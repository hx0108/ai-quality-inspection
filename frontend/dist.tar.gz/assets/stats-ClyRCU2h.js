import{r as t}from"./index-BvfUxQTi.js";function s(){return t.get("/analysis/dashboard/stats")}export{s as g};
