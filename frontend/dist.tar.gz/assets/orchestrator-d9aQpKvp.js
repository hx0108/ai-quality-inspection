import{r as t}from"./index-BvfUxQTi.js";function o(r){return t.post("/orchestrator/run",{task_id:r})}export{o as r};
